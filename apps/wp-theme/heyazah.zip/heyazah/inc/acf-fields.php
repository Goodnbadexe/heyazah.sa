<?php
/**
 * Advanced Custom Fields configuration and setup.
 *
 * @package Heyazah
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

// Check if ACF is installed and active
add_action('admin_notices', function() {
    if ( ! class_exists( 'ACF' ) ) {
        echo '<div class="notice notice-error"><p>' . esc_html__( 'Heyazah Theme requires Advanced Custom Fields PRO to be installed and active.', 'heyazah' ) . '</p></div>';
    }
});
