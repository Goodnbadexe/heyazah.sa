<?php
/**
 * Immersive 3D/360 embeds for Heyazah Project Pages
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_shortcode('heyazah_project_embed', function($atts) {
    ob_start();
    get_template_part('template-parts/project-cloud-embed');
    return ob_get_clean();
});

add_shortcode('heyazah_site_entrance', function($atts) {
    ob_start();
    get_template_part('template-parts/site-entrance');
    return ob_get_clean();
});
