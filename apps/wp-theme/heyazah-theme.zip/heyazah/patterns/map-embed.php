<?php
/**
 * Title: Map Embed
 * Slug: heyazah/map-embed
 * Categories: featured
 */
?>
<!-- wp:group {"layout":{"type":"constrained"},"className":"container py-12"} -->
<div class="wp-block-group container py-12">
	<!-- wp:html {"className":"overflow-hidden rounded-2xl border border-heyazah-fog shadow-card [&>iframe]:h-[420px] [&>iframe]:w-full [&>iframe]:border-0"} -->
	<div class="overflow-hidden rounded-2xl border border-heyazah-fog shadow-card [&>iframe]:h-[420px] [&>iframe]:w-full [&>iframe]:border-0">
		<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14498.41445700947!2d46.6752957!3d24.7135517!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjTCsDQyJzQ4LjgiTiA0NsKwNDAnMzEuMSJF!5e0!3m2!1sen!2ssa!4v1612345678901!5m2!1sen!2ssa" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
	</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
