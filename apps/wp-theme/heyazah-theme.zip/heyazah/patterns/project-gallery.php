<?php
/**
 * Title: Project Gallery
 * Slug: heyazah/project-gallery
 * Categories: featured
 */
?>
<!-- wp:group {"layout":{"type":"constrained"},"className":"container py-16 reveal-on-scroll"} -->
<div class="wp-block-group container py-16 reveal-on-scroll">
	<!-- wp:group {"className":"grid grid-cols-2 gap-3 md:grid-cols-3"} -->
	<div class="wp-block-group grid grid-cols-2 gap-3 md:grid-cols-3">
		<!-- wp:image {"sizeSlug":"large","className":"relative overflow-hidden rounded-xl bg-heyazah-fog shadow-card col-span-2 row-span-2 aspect-square group"} -->
		<figure class="wp-block-image size-large relative overflow-hidden rounded-xl bg-heyazah-fog shadow-card col-span-2 row-span-2 aspect-square group"><img src="" alt="" class="h-full w-full object-cover transition-transform duration-cinematic ease-dramatic group-hover:scale-105"/></figure>
		<!-- /wp:image -->

		<!-- wp:image {"sizeSlug":"large","className":"relative overflow-hidden rounded-xl bg-heyazah-fog shadow-card aspect-square group"} -->
		<figure class="wp-block-image size-large relative overflow-hidden rounded-xl bg-heyazah-fog shadow-card aspect-square group"><img src="" alt="" class="h-full w-full object-cover transition-transform duration-cinematic ease-dramatic group-hover:scale-105"/></figure>
		<!-- /wp:image -->

		<!-- wp:image {"sizeSlug":"large","className":"relative overflow-hidden rounded-xl bg-heyazah-fog shadow-card aspect-square group"} -->
		<figure class="wp-block-image size-large relative overflow-hidden rounded-xl bg-heyazah-fog shadow-card aspect-square group"><img src="" alt="" class="h-full w-full object-cover transition-transform duration-cinematic ease-dramatic group-hover:scale-105"/></figure>
		<!-- /wp:image -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
