<?php
/**
 * Title: Project Metrics
 * Slug: heyazah/project-metrics
 * Categories: featured
 */
?>
<!-- wp:group {"layout":{"type":"constrained"},"className":"container"} -->
<div class="wp-block-group container">
<!-- wp:group {"className":"grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 list-none m-0 p-0 reveal-on-scroll py-8"} -->
<div class="wp-block-group grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 list-none m-0 p-0 reveal-on-scroll py-8">
	<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","right":"var:preset|spacing|20","bottom":"var:preset|spacing|20","left":"var:preset|spacing|20"}},"border":{"radius":"12px","width":"1px"}},"borderColor":"fog","backgroundColor":"paper","className":"flex items-center gap-3 rounded-xl border shadow-card border-heyazah-fog"} -->
	<div class="wp-block-group flex items-center gap-3 rounded-xl border shadow-card border-heyazah-fog has-border-color has-fog-border-color has-paper-background-color has-background" style="border-radius:12px;border-width:1px;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--20)">
		<!-- wp:image {"sizeSlug":"thumbnail","className":"h-7 w-7 opacity-80"} -->
		<figure class="wp-block-image size-thumbnail h-7 w-7 opacity-80"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/amenity.key.svg' ) ); ?>" alt=""/></figure>
		<!-- /wp:image -->
		<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","flexWrap":"nowrap"},"style":{"spacing":{"blockGap":"0"}},"className":"min-w-0"} -->
		<div class="wp-block-group min-w-0">
			<!-- wp:paragraph {"style":{"typography":{"textTransform":"uppercase","letterSpacing":"1px"}},"textColor":"ink","fontSize":"xs","className":"text-xs tracking-wider opacity-60 uppercase"} -->
			<p class="has-ink-color has-text-color has-xs-font-size text-xs tracking-wider opacity-60 uppercase" style="letter-spacing:1px;text-transform:uppercase">Total Units</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"style":{"typography":{"fontWeight":"600"}},"textColor":"primary","className":"truncate text-lg font-semibold"} -->
			<p class="has-primary-color has-text-color truncate text-lg font-semibold" style="font-weight:600">120</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->

	<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","right":"var:preset|spacing|20","bottom":"var:preset|spacing|20","left":"var:preset|spacing|20"}},"border":{"radius":"12px","width":"1px"}},"borderColor":"fog","backgroundColor":"paper","className":"flex items-center gap-3 rounded-xl border shadow-card border-heyazah-fog"} -->
	<div class="wp-block-group flex items-center gap-3 rounded-xl border shadow-card border-heyazah-fog has-border-color has-fog-border-color has-paper-background-color has-background" style="border-radius:12px;border-width:1px;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--20)">
		<!-- wp:image {"sizeSlug":"thumbnail","className":"h-7 w-7 opacity-80"} -->
		<figure class="wp-block-image size-thumbnail h-7 w-7 opacity-80"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/amenity.parking.svg' ) ); ?>" alt=""/></figure>
		<!-- /wp:image -->
		<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","flexWrap":"nowrap"},"style":{"spacing":{"blockGap":"0"}},"className":"min-w-0"} -->
		<div class="wp-block-group min-w-0">
			<!-- wp:paragraph {"style":{"typography":{"textTransform":"uppercase","letterSpacing":"1px"}},"textColor":"ink","fontSize":"xs","className":"text-xs tracking-wider opacity-60 uppercase"} -->
			<p class="has-ink-color has-text-color has-xs-font-size text-xs tracking-wider opacity-60 uppercase" style="letter-spacing:1px;text-transform:uppercase">Parking Spaces</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"style":{"typography":{"fontWeight":"600"}},"textColor":"primary","className":"truncate text-lg font-semibold"} -->
			<p class="has-primary-color has-text-color truncate text-lg font-semibold" style="font-weight:600">300</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->

	<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","right":"var:preset|spacing|20","bottom":"var:preset|spacing|20","left":"var:preset|spacing|20"}},"border":{"radius":"12px","width":"1px"}},"borderColor":"fog","backgroundColor":"paper","className":"flex items-center gap-3 rounded-xl border shadow-card border-heyazah-fog"} -->
	<div class="wp-block-group flex items-center gap-3 rounded-xl border shadow-card border-heyazah-fog has-border-color has-fog-border-color has-paper-background-color has-background" style="border-radius:12px;border-width:1px;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--20)">
		<!-- wp:image {"sizeSlug":"thumbnail","className":"h-7 w-7 opacity-80"} -->
		<figure class="wp-block-image size-thumbnail h-7 w-7 opacity-80"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/amenity.building.svg' ) ); ?>" alt=""/></figure>
		<!-- /wp:image -->
		<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","flexWrap":"nowrap"},"style":{"spacing":{"blockGap":"0"}},"className":"min-w-0"} -->
		<div class="wp-block-group min-w-0">
			<!-- wp:paragraph {"style":{"typography":{"textTransform":"uppercase","letterSpacing":"1px"}},"textColor":"ink","fontSize":"xs","className":"text-xs tracking-wider opacity-60 uppercase"} -->
			<p class="has-ink-color has-text-color has-xs-font-size text-xs tracking-wider opacity-60 uppercase" style="letter-spacing:1px;text-transform:uppercase">Rental Area</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"style":{"typography":{"fontWeight":"600"}},"textColor":"primary","className":"truncate text-lg font-semibold"} -->
			<p class="has-primary-color has-text-color truncate text-lg font-semibold" style="font-weight:600">4,500 m²</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->

	<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","right":"var:preset|spacing|20","bottom":"var:preset|spacing|20","left":"var:preset|spacing|20"}},"border":{"radius":"12px","width":"1px"}},"borderColor":"fog","backgroundColor":"paper","className":"flex items-center gap-3 rounded-xl border shadow-card border-heyazah-fog"} -->
	<div class="wp-block-group flex items-center gap-3 rounded-xl border shadow-card border-heyazah-fog has-border-color has-fog-border-color has-paper-background-color has-background" style="border-radius:12px;border-width:1px;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--20)">
		<!-- wp:image {"sizeSlug":"thumbnail","className":"h-7 w-7 opacity-80"} -->
		<figure class="wp-block-image size-thumbnail h-7 w-7 opacity-80"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/ui.calendar.svg' ) ); ?>" alt=""/></figure>
		<!-- /wp:image -->
		<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","flexWrap":"nowrap"},"style":{"spacing":{"blockGap":"0"}},"className":"min-w-0"} -->
		<div class="wp-block-group min-w-0">
			<!-- wp:paragraph {"style":{"typography":{"textTransform":"uppercase","letterSpacing":"1px"}},"textColor":"ink","fontSize":"xs","className":"text-xs tracking-wider opacity-60 uppercase"} -->
			<p class="has-ink-color has-text-color has-xs-font-size text-xs tracking-wider opacity-60 uppercase" style="letter-spacing:1px;text-transform:uppercase">Delivery</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"style":{"typography":{"fontWeight":"600"}},"textColor":"primary","className":"truncate text-lg font-semibold"} -->
			<p class="has-primary-color has-text-color truncate text-lg font-semibold" style="font-weight:600">Q4 2026</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
