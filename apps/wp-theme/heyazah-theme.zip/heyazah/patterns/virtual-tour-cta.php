<?php
/**
 * Title: Virtual Tour CTA
 * Slug: heyazah/virtual-tour-cta
 * Categories: featured
 */
?>
<!-- wp:group {"layout":{"type":"constrained"},"className":"container py-12 reveal-on-scroll"} -->
<div class="wp-block-group container py-12 reveal-on-scroll">
	<!-- wp:buttons {"className":"flex flex-wrap gap-3"} -->
	<div class="wp-block-buttons flex flex-wrap gap-3">
		<!-- wp:button {"backgroundColor":"primary","textColor":"paper","className":"shadow-card hover:bg-heyazah-accent transition-colors inline-flex items-center gap-2 font-semibold text-sm","style":{"border":{"radius":"999px"}}} -->
		<div class="wp-block-button shadow-card hover:bg-heyazah-accent transition-colors inline-flex items-center gap-2 font-semibold text-sm"><a class="wp-block-button__link has-paper-color has-primary-background-color has-text-color has-background wp-element-button" style="border-radius:999px">Virtual Tour</a></div>
		<!-- /wp:button -->

		<!-- wp:button {"backgroundColor":"paper","textColor":"primary","className":"border border-heyazah-primary hover:bg-heyazah-fog transition-colors inline-flex items-center gap-2 font-semibold text-sm","style":{"border":{"radius":"999px"}}} -->
		<div class="wp-block-button border border-heyazah-primary hover:bg-heyazah-fog transition-colors inline-flex items-center gap-2 font-semibold text-sm"><a class="wp-block-button__link has-primary-color has-paper-background-color has-text-color has-background wp-element-button" style="border-radius:999px">Video</a></div>
		<!-- /wp:button -->
		
		<!-- wp:button {"backgroundColor":"paper","textColor":"primary","className":"border border-heyazah-warm hover:bg-heyazah-warm transition-colors inline-flex items-center gap-2 font-semibold text-sm","style":{"border":{"radius":"999px"}}} -->
		<div class="wp-block-button border border-heyazah-warm hover:bg-heyazah-warm transition-colors inline-flex items-center gap-2 font-semibold text-sm"><a class="wp-block-button__link has-primary-color has-paper-background-color has-text-color has-background wp-element-button" style="border-radius:999px">Brochure</a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
